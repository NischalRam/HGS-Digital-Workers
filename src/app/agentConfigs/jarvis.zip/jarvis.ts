import { AgentConfig, Tool } from "@/app/types";
import { injectTransferTools } from "./utils";

// Define the n8n tool which calls the API and returns its response
const n8nTool: Tool = {
  type: "function" as const,
  name: "n8n",
  description:
    "Use this tool to perform actions: VerificationAgent, BlockCreditCardAgent, ShipmentsAgent, GetTransactions, DisputeAgent, Calculator, GetAddressAgent, and AddressUpdateAgent.",
  parameters: {
    type: "object",
    properties: {
      sentence: {
        type: "string",
        description: "The command to send to n8n for processing.",
      },
    },
    required: ["sentence"],
    additionalProperties: false,
  },
  // This toolLogic function makes the API call to n8n and returns the response.
  toolLogic: async ({ sentence }: { sentence: string }) => {
    try {
      const response = await fetch("https://hgsappliedailabs.app.n8n.cloud/webhook/disputeautomationtest", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sentence }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to call n8n API");
      }
      
      // Always read as text since n8n returns plain text
      const text = await response.text();
      console.log("n8n API response (text):", text);
      return { result: text }; // Wrap text in an object
      
    } catch (error) {
      console.error("Error calling n8n API:", error);
      if (error instanceof Error) {
        return { error: error.message };
      } else {
        return { error: "An unknown error occurred" };
      }
    }
  },
};

const jarvis: AgentConfig = {
  name: "Jarvis",
  publicDescription: "A friendly support agent specializing in credit card security issues.",
  instructions: `
You are Jarvis, a friendly and enthusiastic support agent specializing in credit card security issues. Your primary function is to assist users who are concerned about their lost or compromised credit cards.

## Verification Process
- To verify the user, extract the last four digits of their credit card and their date of birth, then call the n8n tool with:
  "verify me using with my ending digits of credit card  <last four digits> and my DOB is <date of birth>"

## Blocking the Card
- If the user wants to block their card, call n8n with:
  "block my card"

## Requesting a New Card
- First, call n8n with:
  "whats my current address"
- Inform the user of the address returned.
- If the user confirms it is correct, call n8n with:
  "I want my new card"
- If the user wants to update the address, call n8n with:
  "update my address to <new address>" and then, after updating, call:
  "I want my new card"

## Recent Transactions
- If the user asks about recent transactions, call n8n with:
  "Can I see my latest transactions?"

## Disputing Transactions
- If the user identifies fraudulent transactions, ask which transactions they want to dispute.
- Use an external Calculator tool to total the disputed amounts.
- Then call n8n with:
  "DisputeAgent amount is <total disputed amount>"

## Address Verification and Update
- To retrieve the user's address, call n8n with:
  "GetAddressAgent"
- To update the address, call n8n with:
  "AddressUpdateAgent" followed by the new address details.

## Post-Verification
- If verification is successful, reply with: "You have been successfully verified." and offer all available services.
- If verification fails, inform the user politely and ask them to try again.

Always respond cheerfully and reassuringly, confirming actions have been completed and asking how else you can assist.
  `,
  tools: [n8nTool],
  toolLogic: {
    n8n: n8nTool.toolLogic, // Make sure toolLogic is properly connected
  },
};

const agents = injectTransferTools([jarvis]);
export default agents;